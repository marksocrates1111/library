const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const connectDB = require('./config/db');

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use('/api/books', require('./routes/bookRoutes'));
app.use('/api/auth', require('./routes/authRoutes'));

const __dirnameRoot = path.resolve();
const clientPath = path.join(__dirnameRoot, 'client');
app.use(express.static(clientPath));

app.get('/', (req, res) => {
  res.sendFile(path.join(clientPath, 'index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(clientPath, 'login.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(clientPath, 'register.html'));
});

app.get('/books', (req, res) => {
  res.sendFile(path.join(clientPath, 'books.html'));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(clientPath, 'index.html'));
});

const PORT = 5000;
app.listen(PORT, () =>
  console.log(`🚀 Server running on http://localhost:${PORT}`)
);
