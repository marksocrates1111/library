const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

// Book Schema
const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  category: String,
  year: Number
});

const Book = mongoose.model('Book', bookSchema);

// ✅ GET all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ✅ POST (add new book) — matches your frontend call: /api/books/add
router.post('/add', async (req, res) => {
  try {
    const { title, author, category, year } = req.body;

    if (!title || !author) {
      return res.status(400).json({ message: 'Title and author are required' });
    }

    const newBook = new Book({ title, author, category, year });
    await newBook.save();

    res.status(201).json({ message: 'Book added successfully', book: newBook });
  } catch (err) {
    console.error(err);
    res.status(400).json({ message: err.message });
  }
});

// ✅ DELETE book by ID
router.delete('/:id', async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ message: 'Book deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
