const API_ROOT = "http://localhost:5000/api";

async function apiGet(path) {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API_ROOT}${path}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error((await res.json()).message || 'API error');
  return res.json();
}

async function apiPost(path, body) {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API_ROOT}${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error((await res.json()).message || 'API error');
  return res.json();
}

document.addEventListener("DOMContentLoaded", async () => {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "login.html";
    return;
  }

  document.getElementById("userEmail").textContent = localStorage.getItem("userEmail") || 'Signed in';

  const booksContainer = document.getElementById("booksContainer");
  const studentsList = document.getElementById("studentsList");
  const repTotalBooks = document.getElementById("repTotalBooks");
  const repBorrowed = document.getElementById("repBorrowed");

  async function loadAll() {
    try {
      const books = await apiGet('/books');
      booksContainer.innerHTML = books.length ? books.map(b => `
        <div class="book-card">
          <h3>${escapeHtml(b.title)}</h3>
          <div class="muted">${escapeHtml(b.author || '')} • ${escapeHtml(b.category || '')}</div>
          <div style="margin-top:8px; color:var(--muted);">Year: ${b.year || '—'}</div>
        </div>
      `).join('') : '<p>No books yet.</p>';

      try {
        const students = await apiGet('/students');
        studentsList.innerHTML = students.map(s => `<li>${escapeHtml(s.name || s.email)} — <span class="muted">${escapeHtml(s.email)}</span></li>`).join('');
      } catch (e) {
        studentsList.innerHTML = '<li class="muted">Students list requires librarian access.</li>';
      }

      try {
        const summary = await apiGet('/reports/summary');
        repTotalBooks.textContent = summary.totalBooks ?? '—';
        repBorrowed.textContent = summary.borrowed ?? '—';
      } catch (e) {
        repTotalBooks.textContent = '—';
        repBorrowed.textContent = '—';
      }

    } catch (err) {
      console.error(err);
      alert('Failed to load dashboard. Logging out.');
      localStorage.removeItem('token');
      window.location.href = 'login.html';
    }
  }

  function escapeHtml(str = '') {
    return String(str).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  document.getElementById('showAdd').addEventListener('click', () => {
    document.getElementById('addForm').style.display = 'flex';
  });
  document.getElementById('cancelAdd').addEventListener('click', () => {
    document.getElementById('addForm').style.display = 'none';
  });
  document.getElementById('addBookBtn').addEventListener('click', async () => {
    const title = document.getElementById('bTitle').value.trim();
    const author = document.getElementById('bAuthor').value.trim();
    const category = document.getElementById('bCategory').value.trim();
    const year = document.getElementById('bYear').value.trim();
    const msg = document.getElementById('addMsg');
    msg.textContent = '';

    if (!title || !author) { msg.textContent = 'Title and author are required'; return; }

    try {
      await apiPost('/books/add', { title, author, category, year });
      msg.style.color = 'green';
      msg.textContent = 'Book added';
      document.getElementById('bTitle').value=''; document.getElementById('bAuthor').value=''; document.getElementById('bCategory').value=''; document.getElementById('bYear').value='';
      document.getElementById('addForm').style.display = 'none';
      loadAll();
    } catch (e) {
      msg.style.color = '#dc3545';
      msg.textContent = e.message || 'Failed to add';
    }
  });

  document.getElementById('seedBtn').addEventListener('click', async () => {
    try {
      const res = await fetch(`${API_ROOT}/books/seed`);
      const data = await res.json();
      alert(data.message || 'Seed complete');
      loadAll();
    } catch (e) {
      alert('Seed failed: ' + (e.message || ''));
    }
  });

  document.getElementById('refreshBooks').addEventListener('click', loadAll);

  document.getElementById('exportBtn').addEventListener('click', () => {
    window.open(`${API_ROOT}/reports/export`, '_blank');
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userEmail');
    window.location.href = 'login.html';
  });

  loadAll();
  
});
