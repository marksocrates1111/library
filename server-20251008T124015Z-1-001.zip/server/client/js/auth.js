const API_ROOT = "http://localhost:5000/api";

document.addEventListener("DOMContentLoaded", () => {
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("registerName")?.value || '';
      const email = document.getElementById("registerEmail").value;
      const password = document.getElementById("registerPassword").value;
      const msgEl = document.getElementById("registerMsg");

      msgEl.textContent = "";
      try {
        const res = await fetch(`${API_ROOT}/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || data.error || "Registration failed");
        msgEl.style.color = "green";
        msgEl.textContent = "Account created. Redirecting to login…";
        setTimeout(()=> window.location.href = "login.html", 900);
      } catch (err) {
        msgEl.style.color = "#dc3545";
        msgEl.textContent = err.message;
      }
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value;
      const password = document.getElementById("loginPassword").value;
      const msgEl = document.getElementById("loginMsg");

      msgEl.textContent = "";
      try {
        const res = await fetch(`${API_ROOT}/auth/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || data.error || "Login failed");
        localStorage.setItem("token", data.token);

        localStorage.setItem("userEmail", email);
        window.location.href = "dashboard.html";
      } catch (err) {
        msgEl.style.color = "#dc3545";
        msgEl.textContent = err.message;
      }
    });
  }
});
