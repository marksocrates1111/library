document.addEventListener("DOMContentLoaded", async () => {
  const token = localStorage.getItem("token");
  const booksContainer = document.getElementById("booksContainer");
  const addBookForm = document.getElementById("addBookForm");

  // ✅ Modal Elements
  const modal = document.getElementById("bookModal");
  const closeBtn = document.querySelector(".close");
  const modalTitle = document.getElementById("modalTitle");
  const modalAuthor = document.getElementById("modalAuthor");
  const modalCategory = document.getElementById("modalCategory");
  const modalYear = document.getElementById("modalYear");
  const modalDescription = document.getElementById("modalDescription");

  // ✅ Require login
  if (!token) {
    alert("Please log in first!");
    window.location.href = "login.html";
    return;
  }

  // ✅ Load all books (GET /api/books)
  async function loadBooks() {
    try {
      const res = await fetch("http://localhost:5000/api/books", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const books = await res.json();
      displayBooks(books);
    } catch (err) {
      console.error(err);
      booksContainer.innerHTML = "<p>Error loading books.</p>";
    }
  }

  // ✅ Display Books
  function displayBooks(books) {
    if (!books.length) {
      booksContainer.innerHTML = "<p>No books found.</p>";
      return;
    }

    booksContainer.innerHTML = "";
    books.forEach((book) => {
      const card = document.createElement("div");
      card.classList.add("book-card");
      card.innerHTML = `
        <h3>${book.title}</h3>
        <p><strong>Author:</strong> ${book.author}</p>
        <p><strong>Category:</strong> ${book.category}</p>
        <p><strong>Year:</strong> ${book.year}</p>
      `;

      //  📘 Click to open modal
      card.addEventListener("click", () => {
        modalTitle.textContent = book.title;
        modalAuthor.textContent = book.author;
        modalCategory.textContent = book.category;
        modalYear.textContent = book.year;
        modalDescription.textContent =
          book.description || "No description available.";
        modal.style.display = "flex";
      });

      booksContainer.appendChild(card);
    });
  }

  // ✅ Add new book (POST /api/books/add)
  addBookForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const category = document.getElementById("category").value;
    const year = document.getElementById("year").value;

    try {
      const res = await fetch("http://localhost:5000/api/books/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ title, author, category, year }),
      });

      const data = await res.json();
      alert(data.message || "Book added!");
      addBookForm.reset();
      loadBooks(); // Refresh list after adding
    } catch (err) {
      console.error(err);
      alert("Error adding book!");
    }
  });

  // ✅ Seed 20 Sample Books (optional endpoint)
  document.getElementById("seedBtn").addEventListener("click", async () => {
    const res = await fetch("http://localhost:5000/api/books/seed", {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    alert(data.message || "Books seeded!");
    loadBooks();
  });

  // ✅ Logout
  document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "login.html";
  });

  // ✅ Close Modal
  closeBtn.addEventListener("click", () => (modal.style.display = "none"));
  window.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // ✅ Load books initially
  loadBooks();
});
